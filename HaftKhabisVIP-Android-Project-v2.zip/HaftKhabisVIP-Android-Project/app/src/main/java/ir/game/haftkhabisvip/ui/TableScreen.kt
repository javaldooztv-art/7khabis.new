package ir.game.haftkhabisvip.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.game.haftkhabisvip.engine.Rules
import ir.game.haftkhabisvip.model.Card
import ir.game.haftkhabisvip.model.ClientIntent
import ir.game.haftkhabisvip.model.GameState
import ir.game.haftkhabisvip.model.PendingActionType
import ir.game.haftkhabisvip.model.Player

@Composable
fun TableScreen(
    state: GameState,
    myPlayer: Player,
    pile: List<Card>,
    notice: String?,
    onSend: (ClientIntent) -> Unit,
    onShowScores: () -> Unit,
    onLeave: () -> Unit
) {
    val isMyTurn = state.players.getOrNull(state.currentTurnIndex)?.id == myPlayer.id &&
        !state.isRoundOver && !state.isGameOver

    Box(Modifier.fillMaxSize().feltBackground()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 10.dp)) {

            // نوار بالا
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "دست ${state.currentRound.fa()} از ${state.totalRounds.fa()}",
                    color = Color.White.copy(alpha = 0.85f),
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallChip("امتیازها", onShowScores)
                    SmallChip("خروج", onLeave)
                }
            }

            // حریف‌ها
            LazyRow(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally)
            ) {
                items(state.players.filter { it.id != myPlayer.id }, key = { it.id }) { opp ->
                    val turn = state.players.getOrNull(state.currentTurnIndex)?.id == opp.id && !state.isRoundOver
                    OpponentBadge(opp, turn)
                }
            }

            // وسط میز
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                DirectionRing(ccw = state.direction == -1, modifier = Modifier.size(270.dp))

                Column(Modifier.align(Alignment.TopCenter), horizontalAlignment = Alignment.CenterHorizontally) {
                    Crossfade(targetState = state.statusMessage, label = "status") { msg ->
                        StatusPill(msg, Modifier.fillMaxWidth(0.95f))
                    }
                    if (notice != null) {
                        Spacer(Modifier.height(6.dp))
                        StatusPill(notice)
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DeckStack(
                        count = state.deckCount,
                        width = 74.dp,
                        pulse = isMyTurn && state.pendingAction == PendingActionType.NONE
                    ) { onSend(ClientIntent.DrawCard) }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        DiscardPile(pile, 74.dp)
                        ActiveSuitBadge(state)
                    }
                }

                Column(Modifier.align(Alignment.BottomCenter), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (state.sevenChainPenalty > 0) {
                        SevenChainBanner(state.sevenChainPenalty)
                    }
                    if (isMyTurn && state.pendingAction == PendingActionType.EIGHT_STREAK) {
                        Spacer(Modifier.height(6.dp))
                        FancyButton("پایان نوبت ۸ (بدون جایزه)", { onSend(ClientIntent.PassEightBonus) })
                    }
                }
            }

            // پایین: وضعیت من و دست
            Row(
                Modifier.fillMaxWidth().padding(bottom = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val a = if (isMyTurn) pulseAlpha() else 0f
                    AvatarCircle(
                        myPlayer.name, 38.dp,
                        ring = if (isMyTurn) HK.GoldBright.copy(alpha = 0.4f + 0.6f * a) else Color.White.copy(alpha = 0.3f),
                        ringWidth = if (isMyTurn) 3.dp else 1.5.dp
                    )
                    Column {
                        Text(
                            if (isMyTurn) "نوبت شماست!" else "منتظر نوبت…",
                            color = if (isMyTurn) Color(0xFF69F0AE) else Color.LightGray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text("امتیاز شما: ${myPlayer.totalScore.fa()}", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                    }
                }
                FancyButton(
                    text = "تک کارت!",
                    onClick = { onSend(ClientIntent.DeclareTakKard) },
                    enabled = myPlayer.hand.size <= 2 && !myPlayer.saidTakKard,
                    kind = ButtonKind.RED
                )
            }

            FanHand(
                cards = myPlayer.hand,
                myTurn = isMyTurn,
                canPlay = { Rules.canPlay(state, it) },
                onPlay = { onSend(ClientIntent.PlayCard(it.id)) }
            )
        }

        if (isMyTurn && state.pendingAction == PendingActionType.CHOOSE_SUIT) {
            SuitSelectionDialog { onSend(ClientIntent.SelectSuit(it)) }
        }
        if (isMyTurn && state.pendingAction == PendingActionType.GIVE_PENALTY_CARD) {
            GiveCardPenaltyDialog(
                myHand = myPlayer.hand,
                otherPlayers = state.players.filter { it.id != myPlayer.id },
                onConfirm = { cardId, target -> onSend(ClientIntent.GiveCardToPlayer(cardId, target)) }
            )
        }
    }
}

@Composable
private fun SmallChip(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .clip(shape)
            .background(Color(0x66000000))
            .border(1.dp, HK.Gold.copy(alpha = 0.5f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text, color = HK.GoldBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ActiveSuitBadge(state: GameState) {
    val suit = state.activeSuit ?: return
    Row(
        Modifier
            .padding(top = 2.dp)
            .clip(RoundedCornerShape(50))
            .background(Color(0xCCFFFCF4))
            .border(1.5.dp, HK.Gold, RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("حکم", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF333333))
        SuitIcon(suit, 18.dp)
    }
}

@Composable
private fun SevenChainBanner(penalty: Int) {
    val a = pulseAlpha()
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(Brush.horizontalGradient(listOf(Color(0xFFB71C1C), Color(0xFFE53935))))
            .border(2.dp, HK.GoldBright.copy(alpha = 0.3f + 0.7f * a), RoundedCornerShape(50))
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Text(
            "زنجیرهٔ هفت: ${penalty.fa()} کارت جریمه! (دفاع با شاه هم‌خال یا ۷ جدید)",
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun OpponentBadge(p: Player, isTurn: Boolean) {
    val a = if (isTurn) pulseAlpha() else 0f
    Column(Modifier.width(92.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AvatarCircle(
            p.name, 50.dp,
            ring = if (isTurn) HK.GoldBright.copy(alpha = 0.4f + 0.6f * a) else Color.White.copy(alpha = 0.3f),
            ringWidth = if (isTurn) 3.dp else 1.5.dp
        )
        Text(
            p.name,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 3.dp)
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            val shown = minOf(p.hand.size, 6).coerceAtLeast(1)
            Box(Modifier.width(16.dp + 5.dp * (shown - 1)).height(26.dp)) {
                for (i in 0 until shown) {
                    CardBack(width = 16.dp, modifier = Modifier.offset(x = 5.dp * i), elevation = 1.dp)
                }
            }
            Text("×${p.hand.size.fa()}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Text("امتیاز ${p.totalScore.fa()}", color = Color.White.copy(alpha = 0.65f), fontSize = 10.sp)
        if (p.saidTakKard || p.hand.size == 1) {
            Text("تک کارت!", color = Color(0xFFFF5252), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}
