package ir.game.haftkhabisvip.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import ir.game.haftkhabisvip.model.ClientIntent
import ir.game.haftkhabisvip.model.GameState
import ir.game.haftkhabisvip.model.maskedFor
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.concurrent.thread

/**
 * ارتباط بازی روی شبکهٔ محلی (هات‌اسپات گوشی).
 *
 * - میزبان: یک ServerSocket روی TCP_PORT باز می‌کند و هر ثانیه با UDP خودش را اعلام می‌کند.
 * - کلاینت: یا اعلام UDP میزبان را می‌شنود، یا مستقیم به آدرس گِیت‌وی هات‌اسپات وصل می‌شود.
 * - پروتکل: هر پیام یک خط متنی است (HELLO / WELCOME / LOBBY / STATE / INTENT / REJECT).
 *
 * همهٔ callbackها روی Main thread صدا زده می‌شوند.
 */
class HotspotNetworkManager(context: Context, private val listener: Listener) {

    interface Listener {
        // سمت میزبان
        fun onClientJoined(id: String, name: String)
        fun onClientLeft(id: String)
        fun onIntent(fromId: String, intent: ClientIntent)

        // سمت کلاینت
        fun onWelcome(myId: String)
        fun onLobby(names: List<String>)
        fun onState(state: GameState)
        fun onHostLost()
        fun onHostFound(ip: String, name: String)

        // مشترک
        fun onMessage(text: String)
    }

    companion object {
        const val TCP_PORT = 48765
        const val UDP_PORT = 48766
        const val MAX_CLIENTS = 6
        private const val MAGIC = "HKVIP1"
        private const val SEP = "\u0001"
    }

    private class Peer(val id: String, val name: String, val socket: Socket, val writer: BufferedWriter)

    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val sender = Executors.newSingleThreadExecutor()

    @Volatile private var running = false
    @Volatile private var gameStarted = false
    @Volatile private var clientGen = 0

    private var serverSocket: ServerSocket? = null
    private var beaconSocket: DatagramSocket? = null
    private var listenSocket: DatagramSocket? = null
    private var clientSocket: Socket? = null
    private var clientWriter: BufferedWriter? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private val peers = ConcurrentHashMap<String, Peer>()
    private var nextPeerNo = 1

    private fun post(block: () -> Unit) {
        main.post { block() }
    }

    private fun send(writer: BufferedWriter, line: String) {
        sender.execute {
            try {
                synchronized(writer) {
                    writer.write(line)
                    writer.write("\n")
                    writer.flush()
                }
            } catch (_: IOException) {
            }
        }
    }

    // ───────────────────────── میزبان ─────────────────────────

    fun startHost(hostName: String) {
        stop()
        running = true
        gameStarted = false
        thread(isDaemon = true, name = "hk-accept") { acceptLoop() }
        thread(isDaemon = true, name = "hk-beacon") { beaconLoop(hostName) }
    }

    /** بعد از شروع بازی دیگر کسی نمی‌تواند وارد شود. */
    fun markGameStarted() {
        gameStarted = true
    }

    private fun acceptLoop() {
        var ss: ServerSocket? = null
        try {
            ss = ServerSocket()
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(TCP_PORT))
            serverSocket = ss
            while (running) {
                val s = ss.accept()
                thread(isDaemon = true, name = "hk-peer") { servePeer(s) }
            }
        } catch (e: Exception) {
            if (running && serverSocket === ss) {
                post { listener.onMessage("ساخت میز ناموفق بود: ${e.message}") }
            }
        }
    }

    private fun servePeer(socket: Socket) {
        var peer: Peer? = null
        try {
            socket.tcpNoDelay = true
            socket.keepAlive = true
            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
            val writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8))

            socket.soTimeout = 5000
            val hello = reader.readLine() ?: return
            socket.soTimeout = 0
            if (!hello.startsWith("HELLO:")) return

            if (gameStarted) {
                writer.write("REJECT:بازی قبلاً شروع شده است\n"); writer.flush()
                return
            }
            if (peers.size >= MAX_CLIENTS) {
                writer.write("REJECT:میز پر است\n"); writer.flush()
                return
            }

            val name = hello.removePrefix("HELLO:").trim().take(20).ifBlank { "بازیکن" }
            val id = synchronized(this) { "P${nextPeerNo++}" }
            val p = Peer(id, name, socket, writer)
            peer = p
            peers[id] = p
            send(writer, "WELCOME:$id")
            post { listener.onClientJoined(id, name) }

            while (running) {
                val line = reader.readLine() ?: break
                if (line.startsWith("INTENT:")) {
                    val intent = try {
                        json.decodeFromString<ClientIntent>(line.removePrefix("INTENT:"))
                    } catch (_: Exception) {
                        null
                    } ?: continue
                    post { listener.onIntent(id, intent) }
                }
            }
        } catch (_: Exception) {
        } finally {
            peer?.let {
                peers.remove(it.id)
                val leftId = it.id
                post { listener.onClientLeft(leftId) }
            }
            try { socket.close() } catch (_: Exception) {}
        }
    }

    private fun beaconLoop(hostName: String) {
        try {
            val sock = DatagramSocket()
            sock.broadcast = true
            beaconSocket = sock
            val data = "$MAGIC|${hostName.replace("|", " ")}|$TCP_PORT".toByteArray(Charsets.UTF_8)
            while (running && !gameStarted) {
                for (addr in broadcastTargets()) {
                    try {
                        sock.send(DatagramPacket(data, data.size, addr, UDP_PORT))
                    } catch (_: Exception) {
                    }
                }
                Thread.sleep(1000)
            }
        } catch (_: Exception) {
        }
    }

    private fun broadcastTargets(): List<InetAddress> {
        val list = mutableListOf<InetAddress>()
        try { list.add(InetAddress.getByName("255.255.255.255")) } catch (_: Exception) {}
        try {
            NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { ni ->
                if (ni.isUp && !ni.isLoopback) {
                    ni.interfaceAddresses.forEach { ia -> ia.broadcast?.let { list.add(it) } }
                }
            }
        } catch (_: Exception) {
        }
        return list.distinct()
    }

    fun broadcastLobby(names: List<String>) {
        val line = "LOBBY:" + names.joinToString(SEP)
        peers.values.forEach { send(it.writer, line) }
    }

    fun broadcastState(state: GameState) {
        peers.values.forEach { p ->
            send(p.writer, "STATE:" + json.encodeToString<GameState>(state.maskedFor(p.id)))
        }
    }

    // ───────────────────────── کلاینت ─────────────────────────

    fun startDiscovery() {
        stopDiscovery()
        running = true
        acquireMulticast()
        thread(isDaemon = true, name = "hk-discover") {
            var sock: DatagramSocket? = null
            try {
                sock = DatagramSocket(null)
                sock.reuseAddress = true
                sock.broadcast = true
                sock.soTimeout = 1000
                sock.bind(InetSocketAddress(UDP_PORT))
                listenSocket = sock
                val buf = ByteArray(256)
                while (running && listenSocket === sock) {
                    try {
                        val pkt = DatagramPacket(buf, buf.size)
                        sock.receive(pkt)
                        val parts = String(pkt.data, 0, pkt.length, Charsets.UTF_8).split("|")
                        if (parts.size >= 3 && parts[0] == MAGIC) {
                            val ip = pkt.address?.hostAddress
                            val hostName = parts[1]
                            if (ip != null) post { listener.onHostFound(ip, hostName) }
                        }
                    } catch (_: SocketTimeoutException) {
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { sock?.close() } catch (_: Exception) {}
            }
        }
    }

    fun stopDiscovery() {
        try { listenSocket?.close() } catch (_: Exception) {}
        listenSocket = null
        releaseMulticast()
    }

    fun connect(ip: String, name: String) {
        stopDiscovery()
        closeClient()
        running = true
        val gen = ++clientGen
        thread(isDaemon = true, name = "hk-client") {
            var socket: Socket? = null
            try {
                // اگر گوشی هم‌زمان دیتای موبایل دارد، ترافیک باید حتماً از مسیر وای‌فای برود
                socket = wifiNetwork()?.socketFactory?.createSocket() ?: Socket()
                socket.connect(InetSocketAddress(ip.trim(), TCP_PORT), 5000)
                socket.tcpNoDelay = true
                socket.keepAlive = true
                if (gen != clientGen) return@thread
                clientSocket = socket

                val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
                val writer = BufferedWriter(OutputStreamWriter(socket.getOutputStream(), Charsets.UTF_8))
                clientWriter = writer
                send(writer, "HELLO:$name")

                while (running && gen == clientGen) {
                    val line = reader.readLine() ?: break
                    when {
                        line.startsWith("WELCOME:") -> {
                            val id = line.removePrefix("WELCOME:")
                            post { listener.onWelcome(id) }
                        }
                        line.startsWith("LOBBY:") -> {
                            val names = line.removePrefix("LOBBY:").split(SEP).filter { it.isNotEmpty() }
                            post { listener.onLobby(names) }
                        }
                        line.startsWith("STATE:") -> {
                            val st = try {
                                json.decodeFromString<GameState>(line.removePrefix("STATE:"))
                            } catch (_: Exception) {
                                null
                            }
                            if (st != null) post { listener.onState(st) }
                        }
                        line.startsWith("REJECT:") -> {
                            val msg = line.removePrefix("REJECT:")
                            post { listener.onMessage(msg) }
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { socket?.close() } catch (_: Exception) {}
                if (running && gen == clientGen) {
                    post { listener.onHostLost() }
                }
            }
        }
    }

    fun sendIntent(intent: ClientIntent) {
        val w = clientWriter ?: return
        send(w, "INTENT:" + json.encodeToString<ClientIntent>(intent))
    }

    private fun closeClient() {
        clientGen++
        try { clientSocket?.close() } catch (_: Exception) {}
        clientSocket = null
        clientWriter = null
    }

    // ───────────────────────── ابزارها ─────────────────────────

    /** آدرس گِیت‌وی وای‌فای فعلی؛ وقتی به هات‌اسپات میزبان وصل هستیم، همان آدرس خود میزبان است. */
    fun gatewayIp(): String? {
        return try {
            val wm = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val gw = wm.dhcpInfo?.gateway ?: 0
            if (gw == 0) null
            else "${gw and 0xFF}.${(gw shr 8) and 0xFF}.${(gw shr 16) and 0xFF}.${(gw shr 24) and 0xFF}"
        } catch (_: Exception) {
            null
        }
    }

    /** آدرس‌های IPv4 این گوشی (برای نمایش به میزبان). */
    fun localIps(): List<String> {
        return try {
            NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
                .filter { it.isUp && !it.isLoopback }
                .flatMap { ni ->
                    ni.inetAddresses.toList()
                        .filterIsInstance<Inet4Address>()
                        .filter { !it.isLoopbackAddress }
                        .mapNotNull { it.hostAddress }
                }
                .distinct()
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun wifiNetwork(): Network? {
        return try {
            val cm = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            @Suppress("DEPRECATION")
            cm.allNetworks.firstOrNull { n ->
                cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun acquireMulticast() {
        try {
            val wm = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            multicastLock = wm.createMulticastLock("hkvip").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {
        }
    }

    private fun releaseMulticast() {
        try {
            multicastLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
        }
        multicastLock = null
    }

    fun stop() {
        running = false
        gameStarted = false
        try { serverSocket?.close() } catch (_: Exception) {}
        serverSocket = null
        try { beaconSocket?.close() } catch (_: Exception) {}
        beaconSocket = null
        stopDiscovery()
        peers.values.forEach { try { it.socket.close() } catch (_: Exception) {} }
        peers.clear()
        closeClient()
        nextPeerNo = 1
    }
}
